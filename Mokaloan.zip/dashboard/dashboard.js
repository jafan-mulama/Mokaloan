var dashboardService = new DashboardService('app');
dashboardService.renderCard('Example Card 1', 'This is an example card with link 1.', 'https://elizahumanhair.com/');
dashboardService.renderCard('Example Card 2', 'This is an example card with link 2.', 'https://example.com/link2');
dashboardService.renderCard('Example Card 1', 'This is an example card with link 1.', 'https://elizahumanhair.com/');
dashboardService.renderCard('Example Card 2', 'This is an example card with link 2.', 'https://example.com/link2');
dashboardService.renderCard('Example Card 1', 'This is an example card with link 1.', 'https://elizahumanhair.com/');
dashboardService.renderCard('Example Card 2', 'This is an example card with link 2.', 'https://example.com/link2');

